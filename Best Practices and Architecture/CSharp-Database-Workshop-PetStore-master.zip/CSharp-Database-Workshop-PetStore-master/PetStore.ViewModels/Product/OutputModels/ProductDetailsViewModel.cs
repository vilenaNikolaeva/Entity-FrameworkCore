﻿namespace PetStore.ViewModels.Product.OutputModels
{
    public class ProductDetailsViewModel
    {
        public string Name { get; set; }

        public string ProductType { get; set; }

        public string Price { get; set; }
    }
}
