﻿namespace PetStore.ConsoleApplication
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
