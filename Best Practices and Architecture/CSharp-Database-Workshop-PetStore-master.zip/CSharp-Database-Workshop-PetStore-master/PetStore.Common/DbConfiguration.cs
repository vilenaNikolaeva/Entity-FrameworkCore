﻿namespace PetStore.Common
{
    public static class DbConfiguration
    {
        public static string DefConnectionString = @"Server=DESKTOP-2ASBARL\SQLEXPRESS;Database=PetStore;Integrated Security=True;";
    }
}
